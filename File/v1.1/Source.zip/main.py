import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk
import os
import time
from datetime import datetime
import json

class FactorGame:
    def __init__(self, root):
        # 读取设置文件
        self.setting = {}
        with open("file/setting.json",'r',encoding='utf-8') as load_f:
            self.setting = json.load(load_f)

        # 读取语言文件
        self.string = {}
        with open("file/"+self.setting["language"]+".json",'r',encoding='utf-8') as load_f:
            self.string = json.load(load_f)

        #设置主题颜色
        self.bg_color = self.setting["bg_color"]

        # 设置窗口
        self.root = root
        self.root.title("FactorGame")
        self.root.geometry(self.setting["geometry"])
        self.root.configure(bg="#f5f7fa")
        
        # 加载字体
        self.load_custom_font()
        
        # 创建保存目录
        self.path_save = self.setting["path_save"]
        if not os.path.exists(self.path_save):
            os.makedirs(self.path_save)
        
        # 游戏变量
        self.current_number = 0
        self.game_name = ""
        self.log_file = ""
        self.is_A_turn = True
        self.is_game_active = False
        
        # 创建主框架
        self.create_welcome_frame()
    
    def load_custom_font(self):
        """加载自定义字体"""
        # 尝试加载本地字体文件
        self.title_font = ("syht", 24, "bold")
        self.heading_font = ("syht", 16, "bold")
        self.body_font = ("syht", 12)
        self.button_font = ("syht", 12, "bold")
        self.log_font = ("syht", 10)
    
    def create_welcome_frame(self):
        """创建欢迎界面"""
        self.clear_frame()
        
        # 主背景框架
        main_frame = tk.Frame(self.root, bg="#f5f7fa")
        main_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        # 标题区域
        title_frame = tk.Frame(main_frame, bg=self.bg_color, padx=20, pady=15)
        title_frame.pack(fill="x", pady=(0, 20))
        
        tk.Label(
            title_frame, 
            text=self.string["msg_welcome"],
            font=self.title_font, 
            fg="white", 
            bg=self.bg_color
        ).pack(pady=10)
        
        tk.Label(
            title_frame, 
            text="Copyright(C) BCMsoftware. All rights reserved.", 
            font=self.body_font, 
            fg="white", 
            bg=self.bg_color
        ).pack(pady=5)
        
        # 内容区域
        content_frame = tk.Frame(main_frame, bg="#ffffff", padx=30, pady=30,
                               highlightbackground="#e0e7ff", highlightthickness=1)
        content_frame.pack(fill="both", expand=True)
        
        # 左面板 - 输入区域
        left_frame = tk.Frame(content_frame, bg="#ffffff")
        left_frame.pack(side="left", fill="both", expand=True, padx=(0, 20))
        
        # 游戏名称输入
        tk.Label(
            left_frame, 
            text=self.string["msg_gamename"], 
            font=self.heading_font, 
            bg="#ffffff",
            fg="#2c3e50"
        ).pack(anchor="w", pady=(0, 5))
        
        self.game_name_entry = tk.Entry(
            left_frame, 
            font=self.body_font, 
            width=30,
            highlightthickness=1,
            highlightcolor=self.bg_color
        )
        self.game_name_entry.pack(fill="x", pady=(0, 20))
        self.game_name_entry.insert(0, "Game_" + datetime.now().strftime("%Y%m%d_%H%M"))
        
        lang_frame = tk.Frame(left_frame, bg="#ffffff")
        lang_frame.pack(fill="x", pady=(0, 20))
        
        self.language_var = tk.StringVar(value="cn")
        
        # 开始按钮
        start_btn = tk.Button(
            left_frame, 
            text=self.string["msg_startgame"], 
            font=self.button_font,
            bg=self.bg_color, 
            fg="white",
            padx=25,
            pady=10,
            bd=0,
            activebackground=self.bg_color,
            command=self.start_game
        )
        start_btn.pack(pady=10)
        
        # 右面板 - 游戏规则
        right_frame = tk.Frame(content_frame, bg="#ffffff")
        right_frame.pack(side="right", fill="both", expand=True)
        
        rules_frame = tk.LabelFrame(
            right_frame, 
            text=self.string["msg_rule"],
            font=self.heading_font,
            bg="#ffffff",
            fg="#2c3e50",
            padx=15,
            pady=15
        )
        rules_frame.pack(fill="both", expand=True)
        
        rules_text = ""
        for text in self.string["msg_gamerule"]:
            rules_text += text + "\n"
        
        rules_label = tk.Label(
            rules_frame, 
            text=rules_text, 
            font=self.body_font, 
            justify="left",
            bg="#ffffff",
            fg="#34495e"
        )
        rules_label.pack(fill="both", expand=True)
    
    def create_game_frame(self):
        """创建游戏界面"""
        self.clear_frame()
        
        # 主框架
        main_frame = tk.Frame(self.root, bg="#f5f7fa")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # 标题区域
        title_frame = tk.Frame(main_frame, bg=self.bg_color, padx=20, pady=10)
        title_frame.pack(fill="x", pady=(0, 20))
        
        tk.Label(
            title_frame, 
            text=self.string["msg_game"]+" "+self.game_name, 
            font=self.title_font, 
            fg="white", 
            bg=self.bg_color
        ).pack(pady=5)

        # 游戏状态区域
        status_frame = tk.Frame(main_frame, bg="#ffffff", padx=20, pady=15,
                              highlightbackground="#e0e7ff", highlightthickness=1)
        status_frame.pack(fill="x", pady=(0, 20))
        
        tk.Label(
            status_frame, 
            text=self.string["msg_nowuse"], 
            font=self.heading_font,
            bg="#ffffff",
            fg="#2c3e50"
        ).pack(anchor="w", pady=(0, 10))
        
        # 当前数字显示
        num_frame = tk.Frame(status_frame, bg="#ffffff")
        num_frame.pack(fill="x", pady=5)
        
        self.status_label = tk.Label(
            num_frame, 
            text=self.string["msg_nownum"]+" - ", 
            font=self.body_font,
            bg="#ffffff",
            fg="#e74c3c"
        )
        self.status_label.pack(side="left", padx=10)
        
        # 回合指示器
        self.turn_indicator = tk.Label(
            num_frame, 
            text=self.string["msg_hh"]+" - ", 
            font=self.body_font,
            bg="#ffffff",
            fg=self.bg_color
        )
        self.turn_indicator.pack(side="right", padx=10)
        
        # 游戏控制区域
        control_frame = tk.LabelFrame(
            main_frame, 
            text=self.string["msg_control"], 
            font=self.heading_font,
            bg="#ffffff",
            fg="#2c3e50",
            padx=20,
            pady=20,
            highlightbackground="#e0e7ff", 
            highlightthickness=1
        )
        control_frame.pack(fill="both", expand=True, pady=(0, 20))
        
        # 因子选择区域
        factor_frame = tk.Frame(control_frame, bg="#ffffff")
        factor_frame.pack(fill="x", pady=10)
        
        self.factor_label = tk.Label(
            factor_frame, 
            text=self.string["msg_kxyz"], 
            font=self.body_font,
            bg="#ffffff",
            fg="#2c3e50"
        )
        self.factor_label.pack(side="left", padx=(0, 10))
        
        self.factor_combobox = ttk.Combobox(
            factor_frame, 
            font=self.body_font,
            width=15,
            state="readonly"
        )
        self.factor_combobox.pack(side="left", padx=(0, 10))
        
        self.submit_btn = tk.Button(
            factor_frame, 
            text=self.string["msg_choose"], 
            font=self.button_font,
            bg=self.bg_color, 
            fg="white",
            padx=15,
            pady=5,
            bd=0,
            activebackground=self.bg_color,
            command=self.move
        )
        self.submit_btn.pack(side="left", padx=10)
        
        # 新游戏按钮
        new_game_btn = tk.Button(
            control_frame, 
            text=self.string["msg_newgame"], 
            font=self.button_font,
            bg=self.bg_color, 
            fg="white",
            padx=15,
            pady=5,
            bd=0,
            activebackground=self.bg_color,
            command=self.create_welcome_frame
        )
        new_game_btn.pack(side="right", padx=5)
        
        # 游戏日志区域
        log_frame = tk.LabelFrame(
            main_frame, 
            text=self.string["msg_gamelog"], 
            font=self.heading_font,
            bg="#ffffff",
            fg="#2c3e50",
            padx=20,
            pady=15,
            highlightbackground="#e0e7ff", 
            highlightthickness=1
        )
        log_frame.pack(fill="both", expand=True)
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame, 
            font=self.log_font,
            wrap="word",
            height=10,
            padx=10,
            pady=10,
            bg="#f9f9f9",
            fg="#2c3e50"
        )
        self.log_text.pack(fill="both", expand=True)
        self.log_text.config(state="disabled")
    
    def clear_frame(self):
        """清除当前框架内容"""
        for widget in self.root.winfo_children():
            widget.destroy()
    
    def add_log(self, message):
        """添加日志消息"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        
        # 更新日志文本框
        self.log_text.config(state="normal")
        self.log_text.insert("end", log_entry + "\n")
        self.log_text.see("end")
        self.log_text.config(state="disabled")
        
        # 保存到日志文件
        if self.log_file:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(log_entry + "\n")
    
    def get_factors(self, num):
        """获取一个数的所有因子(除1和自身外)"""
        factors = []
        for i in range(2, num):
            if num % i == 0:
                factors.append(i)
        return factors
    
    def start_game(self):
        """开始新游戏"""
        self.game_name = self.game_name_entry.get()
        self.language = self.language_var.get()
        
        # 创建日志文件
        self.log_file = os.path.join(self.path_save, self.game_name+"s.log")
        with open(self.log_file, "w", encoding="utf-8") as f:
            f.write(f"Factor Game: {self.game_name}\n")
            f.write(f"Begin time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

        # 创建游戏界面
        self.create_game_frame()

        # 添加数字输入框
        input_frame = tk.Frame(self.root, bg="#ffffff", padx=20, pady=15)
        input_frame.pack(fill="x", padx=20, pady=10)
        
        self.start_label = tk.Label(
            input_frame, 
            text=self.string["msg_bnum"], 
            font=self.body_font,
            bg="#ffffff",
            fg="#2c3e50"
        )
        self.start_label.pack(side="left", padx=(0, 10))
        
        self.number_entry = tk.Entry(
            input_frame, 
            font=self.body_font, 
            width=10,
            highlightthickness=1,
            highlightcolor=self.bg_color
        )
        self.number_entry.pack(side="left", padx=(0, 10))
        
        self.start_btn = tk.Button(
            input_frame, 
            text=self.string["msg_startgame"], 
            font=self.button_font,
            bg=self.bg_color, 
            fg="white",
            padx=15,
            pady=5,
            bd=0,
            activebackground=self.bg_color,
            command=self.set_starting_number
        )
        self.start_btn.pack(side="left")
    
    def set_starting_number(self):
        """设置起始数字并开始游戏"""
        try:
            num = int(self.number_entry.get())
            if num < 1:
                messagebox.showerror("Error", self.string["msg_big"])
                return
            
            self.current_number = num
            self.is_game_active = True
            
            # 移除
            self.number_entry.destroy()
            self.start_btn.destroy()
            self.start_label.destroy()

            # 先手
            self.turn_indicator.config(text=self.string["msg_hh"]+": Player A", fg="#2ecc71")
            self.add_log("Begin number: "+str(num));
            
            # 更新状态
            self.update_game_state()
        except ValueError:
            messagebox.showerror("Error", self.string["msg_yx"])
    
    def update_game_state(self):
        """更新游戏状态"""
        self.status_label.config(text=self.string["msg_nownum"]+": "+str(self.current_number))
        
        # 获取可用因子
        factors = self.get_factors(self.current_number)
        
        if not factors:  # 没有可用因子，游戏结束
            if self.is_A_turn:
                self.add_log("Player B win!")
                messagebox.showinfo("Game over", "Player B win!")
            else:
                self.add_log("Player A win!")
                messagebox.showinfo("Game over", "Player A win!")
            self.is_game_active = False
            self.turn_indicator.config(text="Game over")
            self.factor_label.destroy()
            self.factor_combobox.destroy()
            self.submit_btn.destroy()
            return
        
        # 更新因子选择框
        self.factor_combobox["values"] = factors
        self.factor_combobox.current(0)
        
        if self.is_A_turn:
            self.turn_indicator.config(text=self.string["msg_hh"]+": PlayerA", fg="#2ecc71")
        else:
            self.turn_indicator.config(text=self.string["msg_hh"]+": PlayerB", fg="#3498db")
    
    def move(self):
        """玩家移动"""
        try:
            factor = int(self.factor_combobox.get())
            factors = self.get_factors(self.current_number)
            
            if factor not in factors:
                messagebox.showerror("Error", self.string["msg_wx"])
                return
            
            if(self.is_A_turn):
                player="Player A"
            else:
                player="Player B"

            self.add_log(f"{player}: {self.current_number} - {factor} = {self.current_number - factor}")
            self.current_number -= factor
            self.is_A_turn = self.is_A_turn==0
            self.update_game_state()
        except:
            messagebox.showerror("Error", self.string["msg_wx"])

if __name__ == "__main__":
    root = tk.Tk()
    game = FactorGame(root)
    root.mainloop()